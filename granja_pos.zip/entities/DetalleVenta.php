<?php
/**
 * Entidad DetalleVenta
 * Representa una línea de producto dentro de una venta.
 *
 * Regla de negocio:
 *   - piezas    → Cuántas unidades físicas salieron (Ej: 2 pavos, 3 sacos).
 *                 Es el campo que se descuenta del stock de inventario.
 *   - peso_neto → Peso total registrado en balanza (Ej: 19.50 Kg).
 *                 Para insumos de peso fijo se calcula: piezas × contenido_estandar.
 *                 Para pavos/aves, es el valor real pesado al momento de la venta.
 *   - subtotal  → Para insumos normales: piezas × precio_venta.
 *                 Para pavos: peso_neto × precio_venta.
 */
class DetalleVenta {
    public $id_detalle;
    public $id_insumo;
    public $piezas;       // Unidades físicas que salen del inventario
    public $peso_neto;    // Peso real en Kg (balanza). 0 si no aplica
    public $precio_venta;
    public $costo_unitario; // Snapshot del costo de producción al momento de la venta
    public $subtotal;

    public function __construct(
        $id_detalle  = null,
        $id_insumo   = null,
        $piezas      = 0,
        $peso_neto   = 0.0,
        $precio_venta= 0.0,
        $costo_unitario = 0.0,
        $subtotal    = 0.0
    ) {
        $this->id_detalle  = $id_detalle;
        $this->id_insumo   = $id_insumo;
        $this->piezas      = $piezas;
        $this->peso_neto   = $peso_neto;
        $this->precio_venta= $precio_venta;
        $this->costo_unitario = $costo_unitario;
        $this->subtotal    = $subtotal;
    }
}
?>
