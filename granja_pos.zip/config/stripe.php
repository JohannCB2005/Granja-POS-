<?php
/**
 * config/stripe.php
 * Configuración de claves de Stripe.
 *
 * IMPORTANTE: No versionar este archivo con claves reales en repositorios públicos.
 * La clave pública (PK) puede estar en el frontend.
 * La clave secreta (SK) solo se usa en el backend (create_payment_intent.php).
 */

// ── Intentar leer desde .env primero ─────────────────────────────────────────
$_envFile = dirname(__DIR__) . '/.env';
$_env     = file_exists($_envFile) ? parse_ini_file($_envFile) : [];

// ── Claves de Stripe ──────────────────────────────────────────────────────────
// Si .env no existe o no tiene las claves, usar los valores hardcoded aquí.
// Actualiza estos valores en producción con tus claves reales de Stripe.

define('STRIPE_PK', $_env['STRIPE_PK']
    ?? 'pk_test_51TsbKFGkAYs8oRccqRVvf9dG7MLhWrYqiK6WBoVpsKpNCrMfRC1EpAQm5TdOFjhX7vC2W95Jg0v4yO59SRGD6Ktu00QoaWgFTd'
);

define('STRIPE_SK', $_env['STRIPE_SK']
    ?? 'sk_test_51TsbKFGkAYs8oRccNiAKvU20n9U7KkjfD9kHrK10eHK93awk8MacImFijQZ8Cic5c41JWMXyB8SD7letvEpv4qVM00cA2SD93y'
);

unset($_envFile, $_env);
